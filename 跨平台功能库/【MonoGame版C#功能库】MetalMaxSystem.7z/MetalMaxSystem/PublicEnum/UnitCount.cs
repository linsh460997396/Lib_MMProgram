﻿namespace MetalMaxSystem
{
    //枚举是值类型

    /// <summary>
    /// 【MM_函数库】单位计数枚举
    /// </summary>
    public enum UnitCount
    {
        All,
        Alive,
        Dead
    }
}
