﻿namespace MetalMaxSystem
{
    /// <summary>
    /// 陆战队员
    /// </summary>
    public class Marine : Unit { }
}
