﻿namespace MetalMaxSystem
{
    /// <summary>
    /// 【MM_函数库】道具
    /// </summary>
    public class Item : Unit 
    { 
        

    }
}
