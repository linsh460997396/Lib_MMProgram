﻿namespace MetalMaxSystem
{
    //枚举是值类型

    /// <summary>
    /// 【MM_函数库】玩家属性操作
    /// </summary>
    public enum PlayerPropOp
    {
        SetTo = 0,
        Add = 1,
        Subtract = 2
    }
}
